import pyslise
from math import pi, cos

p = pyslise.Pyslise(lambda x: 2*cos(2*x), 0, pi, tolerance=1e-5)
y0 = [0,1]
print(p.computeEigenvaluesByIndex(0, 10, y0, y0))
